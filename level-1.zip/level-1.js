// LEVEL 1

// Question 1

var courseAssignment = "CA1 - Luke";

// Question 2

var person = {

    name: "Luke Murray",
    sex: "Male"
}

// Question 3
console.log("\n Question 3");

var outOfStock = true;

if (outOfStock = true) {
    console.log("Out of stock");
} else {
    console.log("In stock");
}

// Question 4
console.log("\n Question 4");

var arrayOfNum = [
    15,
    30,
    45,
    60,
    75
]

for( var a = 0; a < arrayOfNum.length; a++) {
    console.log(arrayOfNum[a]);
}

// Question 5
console.log("\n Question 5");

var startcount = 15;
var endcount = 25;

for(e = startcount; e < endcount; e++) {

    console.log(e);
}

// Question 6
console.log("\n Question 6");

if(startcount = 20) {
    console.log(startcount)
}

// Question 7
console.log("\n Question 7");


var cakes = [
    {
        type: "Chocolate snickers cake",
        number: 12,
        yummy: true
    },
    {
        type: "Moldy",
        number: 20,
        yummy: false
    }
]

for(o = 0; o < cakes.length; o++) {

    console.log(cakes[o].number);
    console.log(cakes[o].yummy);
}

// Question 8
console.log("\n Question 8");

function whatIDontLike(foodtypes) {
    console.log("I don't like " + foodtypes);
}

whatIDontLike("liver");

// Question 9
console.log("\n Question 9");

function subtraction(num1, num2) {
     var sum = num1 - num2;
     console.log(sum);
}

subtraction(23, 15);

// Question 10
console.log("\n Question 10");

var arrayOfFeelings = [

];

function restockArray(feelings) {

    arrayOfFeelings.push(feelings);

    for(i = 0; i < arrayOfFeelings.length; i++)
    console.log(arrayOfFeelings[i]);
}

restockArray("Tingly feelings from figuring it out :D" + ", " + "(and from finaly figuring out that for loop can make array console.logs look prettier)");
